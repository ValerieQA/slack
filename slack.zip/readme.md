## Python
1. Download Python 2.7 from *https://www.python.org/downloads/release/python-2712/*
2. Rum .msi file. Install Python into the default folder *C:\Python27*
3. In the My Computer > System Properties > Advanced System Settings > Environment Variables edit "path" add: *C:\Python27\Scripts* and *C:\Python27*

## Selenium
1. Run *pip install selenium* into the command line

## Chrome
1. Download and install Firefox *https://www.google.com/chrome/browser/desktop/index.html*

## Run Test Cases
1. Unzip files into the folder, for example, *C:\Slack*
2. Open command line in the *C:\Slack* repository. Run *python -m unittest Tests.SlackTest*